import React , {useContext} from 'react'
import './Service.css';
import HeartEmoji from "../../img/heartemoji.png"
import Glasses from "../../img/glassesimoji.png"
import Humble from "../../img/humble.png"
import Card from '../Card/Card';
import Shashank_Resume from "./Shashank_Resume.pdf"
import { themeContext } from '../../Context'


const Services = () => {
  const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
  return (
    <div className='services' id='Services'>
      {/* left side */}
      <div className="awesome">
      <span style={{ color: darkMode ? "white" : "" }}>My Awesome</span>
      <span>services</span>

      <span>Lorem ipsum dolor sit amet consectetur, assumenda!
      <br/> Perferendis dolore et, distinctio sunt doloremque 
     
       laboriosam, quae unde nemo.</span>
       <a href={Shashank_Resume} download>
       <button className='button s-button'> Download CV</button>
       </a>
      
      <div className='blur s-blur' style={{background: "#ABF1FF94"}}></div>
      </div>

      {/* right side */}
      <div className="cards">
      <div style={{left: '14rem'}}>
        <Card
           emoji ={HeartEmoji}
           heading = {'Design'}
          detail = {"React HTML CSS"}
         />
      </div>
      {/* second card */}
      <div style={{left: '-4rem' , top: "12rem"}}>
        <Card
           emoji ={Glasses}
           heading = {'Developer'}
          detail = {"React HTML CSS"}
         />
      </div>

      <div style={{left: '12rem' , top: "19rem"}}>
        <Card
           emoji ={Humble}
           heading = {'UI/UX'}
          detail = {"Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, aliquam?"}
         />
      </div>
      <div className="blur s-blur2" style={{background: "var(--purple)" }}></div>
      </div>
    </div>
  )
}

export default Services
