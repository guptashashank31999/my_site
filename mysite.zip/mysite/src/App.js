
import './App.css';
import Contact from './Components/Contact/Contact';
import Experience from './Components/Experience/Experience';
import Footer from './Components/Footer/Footer';
import Intro from './Components/Intro/Intro';
import Navbar from './Components/Navbar/Navbar';
import Portfolio from './Components/Portfolio/Portfolio';
import Services from './Components/Service/Services';
import Testimonial from './Components/Testmonial/Testmonial';
import Work from './Components/Work/Work';
import { themeContext } from './Context';
import { useContext } from 'react';


function App() {
   const theme = useContext(themeContext)
  const darkMode = theme.state.darkMode
  console.log("darkMode" , darkMode)
   return (
    <div className='App'>
      <Navbar />
      <Intro />
      <Services />
      <Experience />
      <Work /> 
      <Portfolio />

      <Testimonial />
      <Contact />
      <Footer/>
    </div>
   
  );
}

export default App;
